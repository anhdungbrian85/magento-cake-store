var config = {
    map: {
        '*': {
            wsExternalLinks: 'WeSupply_Toolbox/js/order/view/wsExternalLinks'
        }
    },
    shim: {
        wsExternalLinks: {
            deps: ['jquery'],
        }
    }
};
